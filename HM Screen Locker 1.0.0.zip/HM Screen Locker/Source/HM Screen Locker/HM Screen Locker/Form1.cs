﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace HM_Screen_Locker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter streamWriter = new StreamWriter("Message.txt");
            streamWriter.WriteLine(richTextBox1.Text);
            streamWriter.Close();
            StreamWriter writer = new StreamWriter("Password.txt");
            writer.Write(textBox1.Text);
            writer.Close();
            Lock @lock = new Lock();
            @lock.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedItem = "English";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "English")
            {
                label2.Text = "Enter Message to here:";
                label3.Text = "Enter Password to here:";
                button1.Text = "Lock Computer";
                label4.Text = "Language:";
            }
            if (comboBox1.Text == "日本語")
            {
                label2.Text = "ここに表示するメッセージを入力:";
                label3.Text = "ここに解除パスワードを入力:";
                button1.Text = "このパソコンをロック";
                label4.Text = "言語:";
            }
        }
    }
}
