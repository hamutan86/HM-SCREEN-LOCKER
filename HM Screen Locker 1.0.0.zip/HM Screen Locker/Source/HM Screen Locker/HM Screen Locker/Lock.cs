﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace HM_Screen_Locker
{
    public partial class Lock : Form
    {
        int Unlock = 0;
        public Lock()
        {
            InitializeComponent();
        }

        private void Lock_Load(object sender, EventArgs e)
        {
            StreamReader streamReader = new StreamReader("Message.txt");
            label1.Text = streamReader.ReadToEnd();
            streamReader.Close();
            StreamReader reader = new StreamReader("Password.txt");
            label2.Text = reader.ReadToEnd();
            reader.Close();
        }

        private void Lock_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Unlock == 1)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader streamReader = new StreamReader("Password.txt");
            if (textBox1.Text == label2.Text)
            {
                Unlock = 1;
                MessageBox.Show("Correct Password!", "Unlocked!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
            else
            {
                MessageBox.Show("Wrong Password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
